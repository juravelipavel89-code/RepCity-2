# RepCity 0.4 — Accounts and cloud sync

Dark fitness tracker prototype built with Flutter.

## New in 0.4
- Registration and sign-in forms in Profile.
- Optional Supabase initialization via `--dart-define`.
- Initial cloud download/merge after app startup when a session exists.
- Automatic cloud upsert after adding/editing a workout.
- Cloud delete after deleting a workout.
- Manual Sync Now control.
- SQL schema and Row Level Security policies in `supabase/schema.sql`.

## Run
```bash
flutter pub get
flutter run --dart-define=SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
```

Run `supabase/schema.sql` in Supabase SQL Editor first. Never put the service_role key in the app.

See `docs/CLOUD_SETUP.md` for setup and limitations.

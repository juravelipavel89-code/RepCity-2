# RepCity 0.3 — Cloud backend setup

This package prepares the Supabase database and Flutter client bridge. It does not contain project credentials and it does not claim that a live Supabase project has already been provisioned.

## 1. Create the Supabase project
1. Open https://supabase.com and create a project.
2. Choose a region reasonably close to your users (for Moldova, a European region is a sensible starting point).
3. Save the database password privately.
4. In Project Settings → API, copy the Project URL and the publishable key. Do not copy the `service_role` secret into the app.

## 2. Create the database
1. Open SQL Editor in the Supabase dashboard.
2. Open `supabase/schema.sql` from this project.
3. Paste the complete SQL and run it.
4. Check Table Editor for `profiles`, `exercise_entries`, `friend_requests`, `friendships`, `challenges`, and `challenge_participants`.
5. Check that `global_leaderboard` appears under database views.

The schema enables Row Level Security (RLS). Exercise records are private to their owner. Profiles are visible to authenticated users to support public ranking and friend search. Friend request acceptance/decline is performed through checked database functions.

## 3. Add Flutter dependency
The project uses `supabase_flutter`. Run:

```bash
flutter pub get
```

## 4. Configure the app without hard-coding keys
Run the app with:

```bash
flutter run \
  --dart-define=SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co \
  --dart-define=SUPABASE_PUBLISHABLE_KEY=YOUR_PUBLISHABLE_KEY
```

In `main.dart`, initialize the SDK before `runApp`:

```dart
import 'package:supabase_flutter/supabase_flutter.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const url = String.fromEnvironment('SUPABASE_URL');
  const key = String.fromEnvironment('SUPABASE_PUBLISHABLE_KEY');
  if (url.isNotEmpty && key.isNotEmpty) {
    await Supabase.initialize(url: url, anonKey: key);
  }
  runApp(const RepCityApp());
}
```

Only the public client key belongs in the app. RLS is the security boundary; a mobile app cannot keep a service-role secret.

## 5. Connect registration and login
`lib/services/cloud_sync.dart` contains ready methods:
- `signUp(email, password, username)` — creates the Supabase Auth account; a database trigger creates the public profile.
- `signIn(email, password)` — password login.
- `signOut()` — ends the session.
- `authChanges` — stream for reacting to login/logout.

The Profile tab now contains Create Account and Sign In forms.

## 6. Enable cloud sync for workout history
The bridge provides `uploadEntries()` and `downloadEntries()`.
- After login, download cloud entries and merge them into the local ledger by `id`.
- When a workout is added, edited, or deleted, queue the corresponding cloud operation.
- Uploads use `(user_id, id)` as the conflict key, so retrying an upload does not create duplicate rows.
- For this first version, a simple merge-by-ID is used. A later version should add an explicit delete tombstone and conflict policy so deletions sync correctly across multiple devices.

Important: the existing app currently stores its ledger locally. After sign-in, the app downloads cloud records and merges by record ID. New and edited entries are automatically upserted; deletions are sent to Supabase. The Profile tab includes a manual Sync Now action.

## 7. Real global and friends rankings
`globalLeaderboard()` reads `global_leaderboard`. XP is computed by SQL from exercise rows using the same provisional rules as the prototype. The app never uploads an XP total supplied by the user.

Friend search and request methods are included. A friends-only leaderboard query/UI is the next integration task after account screens are connected.

## 8. Challenges
The schema includes challenge definitions and participant membership. Challenge administration should be restricted to trusted dashboard/admin workflows; regular app users can read active challenges and join/leave them. Challenge progress UI and scheduled challenge rotation are not yet connected.

## 9. Test checklist before release
- Create two test accounts and confirm they receive distinct profiles.
- Verify account A cannot read account B's exercise rows through the API.
- Add entries offline, sign in, sync, then reinstall/sign in on another device and compare totals.
- Test edit/delete behavior after implementing cloud delete tombstones.
- Send and accept a friend request using two accounts.
- Confirm the leaderboard updates after entries are synced.
- Test password reset, email confirmation settings, and account deletion flow.
- Run `flutter analyze`, `flutter test`, and a release APK build on a machine with Flutter/Android SDK installed.

## Current status
- Supabase SQL schema: prepared, not executed in a live project.
- Flutter cloud service bridge: prepared, not compile-tested in this environment.
- Login/register UI: added to the Profile tab.
- Automatic sync: wired to add/edit/delete actions and initial post-login/startup merge; true background/offline queueing is still future work.
- Real deployed leaderboard: requires a live Supabase project and integration.
- APK: not built or device-tested.
